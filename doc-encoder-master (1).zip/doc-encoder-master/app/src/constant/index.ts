
export const SPACE_DELIMITER_CHECK = /[\w\s]+/

export const COMMA_DELIMITER_CHECK =  /^(?:[a-zA-Z0-9 ]+,)*[a-zA-Z0-9 ]+$/
