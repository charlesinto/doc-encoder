export { Components, JSX } from './components';
import '@stencil-community/router';
